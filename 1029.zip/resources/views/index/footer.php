<script type='text/javascript' src='<?php echo config('local')['website']; ?>/static/js/theme/slides.js?ver=24/09/2017'></script>
<script type='text/javascript' src='<?php echo config('local')['website']; ?>/static/js/theme/jquery.qrcode.min.js?ver=24/09/2017'></script>
<script type='text/javascript' src='<?php echo config('local')['website']; ?>/static/js/theme/sticky.js?ver=1.6.0'></script>
<script type='text/javascript' src='<?php echo config('local')['website']; ?>/static/js/theme/jquery-ias.js?ver=2.2.1'></script>
<script type='text/javascript' src='<?php echo config('local')['website']; ?>/static/js/theme/jquery.lazyload.js?ver=24/09/2017'></script>
<script type='text/javascript' src='<?php echo config('local')['website']; ?>/static/js/theme/tipso.js?ver=1.0.1'></script>
<script type='text/javascript' src='<?php echo config('local')['website']; ?>/static/js/theme/script.js?ver=24/09/2017'></script>
<script type='text/javascript' src='<?php echo config('local')['website']; ?>/static/js/theme/flexisel.js?ver=24/09/2017'></script>
<script type='text/javascript' src='<?php echo config('local')['website']; ?>/static/js/theme/superfish.js?ver=24/09/2017'></script>
</body>
</html>