<?php
?>
<main id="main" class="site-main" role="main">
    <article  class="tag-xss tag-3122 dfl">
        <?php
        echo $list;
        ?>    </article>

</main>
