
    <aside id="php_text-6" class="widget php_text wow fadeInUp" data-wow-delay="0.3s"><h3 class="widget-title"><span class="title-i"><span class="title-i-t"></span><span class="title-i-b"></span><span class="title-i-b"></span><span class="title-i-t"></span></span>博主站点推荐</h3><div class="textwidget widget-text"><div class="qz-box">
                <a class="qz-link qza" href="javascript:;" target="_blank" rel="bookmark">
                    <span class="qz-icon"><i class="be be-yunfuwuqiECS"></i></span>
                    <span class="qz-title">敬请期待</span>
                </a>
                <a class="qz-link qzd" href="javascript:;" rel="bookmark" target="_blank">
                    <span class="qz-icon"><i class="be be-a900"></i></span>
                    <span class="qz-title">敬请期待</span>
                </a>
                <a class="qz-link qzc" href="javascript:;" target="_blank" rel="bookmark">
                    <span class="qz-icon"><i class="be be-yuqizhubao"></i></span>
                    <span class="qz-title">敬请期待</span>
                </a>
                <a class="qz-link qzb" href="javascript:;" target="_blank" rel="bookmark">
                    <span class="qz-icon"><i class="be be-zaixianshangcheng"></i></span>
                    <span class="qz-title">敬请期待</span>
                </a>
                <div class="clear"></div>
            </div></div><div class="clear"></div>
    </aside>
    <aside id="about-2" class="widget about wow fadeInUp" data-wow-delay="0.3s"><h3 class="widget-title"><span class="title-i"><span class="title-i-t"></span><span class="title-i-b"></span><span class="title-i-b"></span><span class="title-i-t"></span></span>站长介绍</h3>
        <div id="feed_widget">
            <div class="feed-about">
                <div class="about-main">
                    <div class="about-img">
                        <img src="<?php echo config('local')['website']; ?>/static/image/smile.jpg" alt="name"/>
                    </div>
                    <div class="about-name">花好月圆</div>
                    <div class="about-the">一个名不经传的“大龄”苦逼站长！</div>
                </div>
                <div class="clear"></div>
                <div class="about-inf">
                    <span class="about-pn">文章 731</span>
                    <span class="about-cn">留言 13122</span>
                </div>
            </div>
        </div>
        <div class="clear"></div>
    </aside>
    <aside id="recent_comments-4" class="widget recent_comments wow fadeInUp" data-wow-delay="0.3s"><h3 class="widget-title"><span class="title-i"><span class="title-i-t"></span><span class="title-i-b"></span><span class="title-i-b"></span><span class="title-i-t"></span></span>近期评论</h3>
        <div id="message" class="message-widget">
            <ul>
                <li>
                    <a href="javascript:;" title="" rel="external nofollow">
                        【<?php echo $now; ?>】杭州哪里好玩？ </a>
                </li>
                <li>
                    <a href="javascript:;" title="" rel="external nofollow">
                        北京哪里好玩？ </a>
                </li>
            </ul>
        </div>
        <div class="clear"></div>
    </aside>
    <aside id="wpz_widget-2" class="widget widget_wpz wow fadeInUp" data-wow-delay="0.3s"> <div class="wpz_widget_content" id="wpz_widget-2_content" data-widget-number="2">
            <div class="wpz-tabs has-3-tabs">
                <span class="tab_title"><a href="#" title="大家喜欢" id="popular-tab"></a></span>
                <span class="tab_title"><a href="#" title="热门文章" id="hot-tab"></a></span>
                <span class="tab_title"><a href="#" title="最近留言" id="comments-tab"></a></span>
                <div class="clear"></div>
            </div>
            <!--end .tabs-->
            <div class="clear"></div>
            <div class="new_cat">
                <div id="popular-tab-content" class="tab-content">
                </div> <!--end #popular-tab-content-->
                <div id="hot-tab-content" class="tab-content">
                    <ul></ul>
                </div> <!--end #tags-tab-content-->
                <div id="comments-tab-content" class="tab-content">
                    <ul></ul>
                </div> <!--end #comments-tab-content-->
                <div class="clear"></div>
            </div> <!--end .inside -->
            <div class="clear"></div>
        </div><!--end #tabber -->
        <script type="text/javascript">jQuery(function($) {$('#wpz_widget-2_content').data('args',{"allow_pagination":"1","post_num":"5","comment_num":null,"viewe_days":"30","like_days":"30","show_thumb":"1","pcat":""});});</script>
        <div class="clear"></div>
    </aside>
    <aside id="readers-2" class="widget readers wow fadeInUp" data-wow-delay="0.3s"><h3 class="widget-title"><span class="title-i"><span class="title-i-t"></span><span class="title-i-b"></span><span class="title-i-b"></span><span class="title-i-t"></span></span>读者墙</h3>
        <div id="readers_widget" class="readers">
            <div class="readers-avatar"><span><a href="javascript:;" title="懿古今  1 个脚印" target="_blank" rel="external nofollow"><img src="<?php echo config('local')['website']; ?>/static/image/reader_example.png" class="avatar avatar-96" height="96" width="96"></a></span></div>
        </div>
        <div class="clear"></div>
    </aside>
    <aside id="linkcat-1210" class="widget widget_links wow fadeInUp" data-wow-delay="0.3s"><h3 class="widget-title"><span class="title-i"><span class="title-i-t"></span><span class="title-i-b"></span><span class="title-i-b"></span><span class="title-i-t"></span></span>友情链接</h3>
        <ul class='xoxo blogroll'>
            <li><a href="javascript:;" rel="acquaintance" target="_blank">敬请期待</a></li>
            <li><a href="javascript:;" title="寻找你的友情链接，这里是我们的“个人网站”共享与发布平台" target="_blank">敬请期待</a></li>
            <li><a href="javascript:;" rel="nofollow" title="独立。" target="_blank">敬请期待</a></li>
        </ul>
        <div class="clear"></div>
    </aside>
